﻿#include <stdio.h>

void main()
{
  // int a = 1, sum = 0;
  int a = 0, sum = 0;
  while (a <= 100)
  {
    sum += a;
    // printf("1부터 100까지의 홀수의 합은 %d입니다.\n", sum);
    printf("0부터 100까지의 짝수의 합은 %d입니다.\n", sum);
    a += 2;
  }
  // printf("1부터 100까지의 합은 %d입니다.\n", sum);
}