#include <stdio.h>

void main()
{
  int a = 10;
  int b = 4;
  float c = a / b;
  printf("a / b = %f", c);
}