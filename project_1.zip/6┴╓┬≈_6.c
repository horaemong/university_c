﻿#include <stdio.h>

void main()
{
  int i = 1, j;
  do
  {
    j = 1;

    printf("%d단\n", i);

    do
    {
      printf("%d * %d = %d\n", i, j, i * j);
      j++;
    } while (j <= 9);
    i++;
  } while (i <= 9);
}