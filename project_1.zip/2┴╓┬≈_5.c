#include <stdio.h>

void main()
{
  char a = 'A';
  int a2 = 66;
  char a3 = a2 + 1;
  printf("a=======>%c\n", a);
  printf("a=======>%d\n", a);
  printf("a2=======>%c\n", a2);
  printf("a3=======>%c\n", a3);
  printf("a3=======>%d\n", a3);
}