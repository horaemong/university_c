﻿#include <stdio.h>

void main()
{
  char re;
  // scanf_s("%c", &re);
  re = getchar();

  switch (re)
  {
  case 'a':
    puts("당신은 1을 입렵했군요.\n");
    break;
  case 'b':
    puts("당신은 2를 입렵했군요.\n");
    break;
  case 'c':
    puts("당신은 3을 입렵했군요.\n");
    break;
  case 'd':
    puts("당신은 4를 입렵했군요.\n");
    break;

  default:
    puts("1~4 외의 숫자를 입력했군요.\n");
    break;
  }
}