﻿#include <stdio.h>

void main()
{
  // for ver.
  // int a, sum = 0;
  // for (int i = 0; i < 5; i++)
  // {
  //   printf("값을 입력하세요. : ");
  //   scanf_s("%d", &a);
  //   sum += a;
  // }
  // printf("5개의 값의 합은 %d입니다.\n", sum);

  // while ver.
  int i = 0, a, sum = 0;
  while (i < 5)
  {
    printf("값을 입력하세요. : ");
    scanf_s("%d", &a);
    sum += a;
    i++;
  }
  printf("5개의 값의 합은 %d입니다.\n", sum);
}