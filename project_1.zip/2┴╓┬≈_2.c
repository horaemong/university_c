#include <stdio.h>

void main()
{
  int a = 3, b = 5;
  printf("가로 길이가 %d, 세로 길이가 %d인 직사각형의 둘레는 = %d", a, b, 2 * (a + b));
}