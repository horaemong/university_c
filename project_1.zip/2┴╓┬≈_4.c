#include <stdio.h>

void main()
{
  float f = 3.2455677109;
  double d = 3.2455677109;

  printf("float value = %12.10f\n", f);
  printf("double value = %12.10lf\n", d);
}