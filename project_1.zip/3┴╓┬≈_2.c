#include <stdio.h>

void main()
{
  int a1, a2;
  double avg;
  a1 = 90;
  a2 = 65;
  avg = (double)(a1 + a2) / 2;
  printf("avg= % f\n", avg);
}