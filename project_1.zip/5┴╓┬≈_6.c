﻿#include <stdio.h>

void main()
{
  int a = 0, sum = 0;
  do
  {
    a += 2;
    sum += a;
  } while (a < 100);
  printf("0부터 100까지의 짝수의 합은 %d입니다.\n", sum);
}