﻿#include <stdio.h>

void main()
{
  // if ver.
  /*int a, sum = 0;
  for (;;)
  {
    printf("값을 입력하세요. : ");
    scanf_s("%d", &a);
    if (a == 999)
    {
      break;
    }
  }*/

  // while ver.
  int a, sum = 0;
  while (1)
  {
    printf("값을 입력하세요. : ");
    scanf_s("%d", &a);
    if (a == 999)
    {
      printf("입력한 값의 합은 %d이다.\n", sum);
      break;
    }
    sum += a;
  }
}