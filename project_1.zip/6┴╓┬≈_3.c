﻿#include <stdio.h>

void main()
{
  int i, j;
  for (i = 1; i <= 9; i++)
  {
    printf("%d단 :\t", i);
    for (j = 1; j <= 9; j++)
    {
      printf("%2d * %d = %2d\t", i, j, i * j);
    }
    printf("\n");
  }
}