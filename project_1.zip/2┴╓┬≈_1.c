#include <stdio.h>

void main(void)
{
  int a = 123;
  printf("현재 a값에 5를 더한 결과 = %d", a + 5);
  printf("현재 a값에서 100을 뺀 결과 = %d", a - 100);
  printf("현재 a값에 2를 곱한 결과 = %d", a * 2);
  printf("현재 a값을 5를 나눈 결과 = %d", a / 5);
}
