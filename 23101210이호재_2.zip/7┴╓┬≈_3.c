﻿#include <stdio.h>

void main()
{
  int num;

  while (1)
  {
    puts("숫자를 입력하세요. : ");
    scanf_s("%d", &num);

    if (num == 0)
      break;

    if (num % 3 == 0)
    {
      printf("%d는 3의 배수입니다.\n", num);
    }
    else
    {
      printf("%d는 3의 배수가 아닙니다.\n", num);
    }
    printf("\n");
  }
}