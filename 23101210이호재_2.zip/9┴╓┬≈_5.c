﻿#include <stdio.h>
#include <math.h>

void main()
{
  int a;
  double b = 16.0;
  scanf_s("%d", &a);
  printf("입력한 값의 절댓값은 %d입니다.\n", abs(a));
  printf("b의 제곱근은 %f입니다.", sqrt(b));
}