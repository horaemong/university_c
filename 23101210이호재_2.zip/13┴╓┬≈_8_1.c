﻿#include <stdio.h>

int a;
calc_one();

void main()
{
  printf("값을 입력하세요 : ");
  scanf_s("%d", &a);
  calc_one();
}