﻿#include <stdio.h>
#define SIZE 10

int calc_sum(int ex[]);

void main()
{
  int sample[] = {75, 70, 85, 90, 65, 55, 45, 75, 55, 90};
  int avg;
  // avg = calc_sum(samplem, 10) / 10;
  int length = sizeof(sample) / sizeof(*sample);
  avg = calc_sum(sample, length) / length;
  // avg = calc_sum(sample) / SIZE;
  printf("평균은 %d입니다.\n", avg);
}

int calc_sum(int ex[], int length)
{
  int i, total = 0;
  /*for (i = 0; i < SIZE; i++)
  {
    total += ex[i];
  }*/
  for (i = 0; i < length; i++)
  {
    total += ex[i];
  }
  return total;
}
