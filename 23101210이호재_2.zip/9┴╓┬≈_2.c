#include <stdio.h>

void main()
{
  int sample[7] = {10, 20, 30, 40, 50};
  int i;

  for (i = 0; i < 7; i++)
    printf("sample[%d] = %d\n", i, sample[i]);
}

void main()
{
  // char sample[5] = {'a', 'b', 'c'};
  char sample[5] = "abc";
  int i;

  for (i = 0; i < 5; i++)
    printf("sample[%d] = %d\n", i, sample[i]);
}

void main()
{
  int aa[] = {10, 20, 30, 40, 50};
  int count = sizeof(aa) / sizeof(int);
  printf("배열 aa의 요소의 개수는 %d입니다.\n", count);
}
