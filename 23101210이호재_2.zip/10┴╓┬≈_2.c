﻿#include <stdio.h>

int factorial(int x);

void main()
{
  int num;
  scanf_s("%d", &num);
  printf("%d! = %d\n", num, factorial(num));
}

int factorial(int x)
{
  if (x == 1)
  {
    return 1;
  }
  else
  {
    return x * factorial(x - 1);
  }
}
