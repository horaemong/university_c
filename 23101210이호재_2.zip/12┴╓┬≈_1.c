﻿#include <stdio.h>

void main()
{
  char c = 'A';
  int i = 5;
  char *cp = &c;
  int *ip = &i;

  printf("c의 값: %c, cp의 값: %c\n", c, (*cp)++);
  printf("i의 값: %d, ip의 값: %d\n", i, *ip += 1);
  printf("%c\n", *cp + 1);
}