﻿#include <stdio.h>

void main()
{
  char strarr[] = "wonderful";
  char *arr = "world";
  printf("strarr의 내용 : %s\n", strarr);
  printf("arr 포인터 결과 = %s\n", arr);
}