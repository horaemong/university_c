﻿#include <stdio.h>

int r;
float s;

void main()
{
  r = 10;
  calc_circle();
  printf("원의 너비 : %f\n", s);
}

float calc_circle()
{
  s = 3.14 * r * r;
}