﻿#include <stdio.h>

int plus(int x, int y);
int sub(int x, int y);
int mul(int x, int y);
float divide(int x, int y);

void main()
{
  int x, y;
  printf("두 정수를 입력하세요: ");
  scanf_s("%d %d", &x, &y);
  printf("%d + %d = %d\n", x, y, plus(x, y));
  printf("%d - %d = %d\n", x, y, sub(x, y));
  printf("%d * %d = %d\n", x, y, mul(x, y));
  printf("%d / %d = %.2f\n", x, y, divide(x, y));
}

int plus(int x, int y)
{
  return x + y;
}

int sub(int x, int y)
{
  return x - y;
}

int mul(int x, int y)
{
  return x * y;
}

float divide(int x, int y)
{
  return (float)x / y;
}