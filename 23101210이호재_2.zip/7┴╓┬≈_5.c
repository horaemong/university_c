﻿#include <stdio.h>

void main()
{

  // printf("3과 5의 배수는 : ");
  // for (int i = 1; i <= 100; i++)
  // {
  //   if (i % 3 == 0 && i % 5 == 0)
  //     printf("%7d", i);
  // }
  // printf("\n");

  int n, m;
  printf("숫자를 두 개 입력하세요 : ");
  scanf_s("%d %d", &n, &m);
  printf("%d~%d에서의 3과 5의 배수는 : ", n, m);
  for (int i = n; i <= m; i++)
  {
    if (i % 3 == 0 && i % 5 == 0)
      printf("%7d", i);
  }
  printf("\n");
}