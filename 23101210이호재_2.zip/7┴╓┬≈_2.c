﻿#include <stdio.h>

void main()
{
  int num;

  while (1)
  {
    puts("숫자를 입력하세요.");
    scanf_s("%d", &num);

    if (num == 999)
    {
      break;
    }

    printf("%d의 약수는 :", num);
    for (int i = 1; i <= num; i++)
    {
      if (num % i == 0)
        printf("%7d", i);
    }
    puts("\n");
  }
}