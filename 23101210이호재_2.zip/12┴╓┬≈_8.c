﻿#include <stdio.h>

void main()
{
  char *p[3] = {"wonderful", "world", "wow"};
  for (int i = 0; i < 3; i++)
  {
    printf("%s\n", p[i]);
  }
}