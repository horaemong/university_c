﻿#include <stdio.h>

void main()
{
  int n;

  while (1)
  {
    printf("숫자를 입력하세요. : ");
    scanf_s("%d", &n);

    if (n == 0)
      break;

    printf("%d의 배수는 : ", n);
    for (int i = 1; i <= 100; i++)
    {
      if (i % n == 0)
        printf("%7d", i);
    }
    printf("\n");
  }
}