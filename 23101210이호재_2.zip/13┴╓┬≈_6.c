#include <stdio.h>

void main()
{
  int i = 0, j = 10;
  {
    int i = 20;
    printf("i = %d\n", i);
    printf("j = %d\n\n", j);
  }
  printf("i = %d\n", i);
  printf("j = %d\n", j);
}