﻿#include <stdio.h>

void main()
{
  int i = 0, x = 10, y = 20;
  printf("초기상태 x=%d, y=%d\n", x, y);
  {
    int x = 0, y = 0;
    for (i = 0; i < 10; i++)
    {
      y++;
      x += y;
      printf("x=%d, y=%d\n", x, y);
    }
  }
  printf("최종결과 x=%d, y=%d\n", x, y);
}