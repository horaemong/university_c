﻿#include <stdio.h>

void main()
{
  char strarr[7][10] = {"sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"};
  int i;
  for (i = 0; i < 7; i++)
  {
    printf("%s\n", strarr[i]);
  }
}